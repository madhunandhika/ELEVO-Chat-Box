# ELEVO – Project Documentation

**Project:** ELEVO – AI Chatbot
**Subject:** Front End Technologies
**Activities covered:**
1. Product landing page using CSS3 Flexbox and Grid with dark/light mode toggle (CO1–CO5)
2. Interactive registration form with CSS animations and real-time client-side validation (CO1–CO5)

---

## 1. Introduction
ELEVO is a web-based chatbot that answers study, coding and everyday questions. It works **without internet** using a built-in knowledge base, and gives **AI answers on any topic** when a free Google Gemini key is added. It can also create images from a text description.

The project has three connected pages:

| Page | File | Purpose |
| --- | --- | --- |
| Landing page | `index.html` | Introduces ELEVO as a product (Activity 1) |
| Registration | `register.html` | Sign-up form with animations and live validation (Activity 2) |
| Chatbot | `chat.html` | The working chatbot with saved chat history |

Everything is written in raw HTML, CSS and JavaScript. No Bootstrap, Tailwind or other UI framework is used.

## 2. Objectives
- Build a responsive product landing page using **Flexbox** and **CSS Grid**.
- Add a **dark/light mode toggle** that works on every page and is remembered.
- Build a registration form that **validates input while the user types**.
- Use **CSS animations** to give clear feedback (errors, success, loading).
- Build a chatbot that **always replies**, even with no internet.
- Design **mobile-first** and publish the project with **GitHub Pages**.

## 3. Course Outcome Mapping
| CO | Where it is covered |
| --- | --- |
| CO1 | Semantic HTML structure on all three pages (`header`, `nav`, `main`, `section`, `article`, `aside`, `footer`, `form`) |
| CO2 | CSS styling with variables, transitions and `@keyframes` animations |
| CO3 | Responsive layout: Flexbox, Grid and mobile-first media queries |
| CO4 | JavaScript: theme toggle, real-time validation, chatbot logic, `localStorage`, `fetch` |
| CO5 | Complete tested project, documented and published on GitHub Pages |

> Note: Match these to the exact CO wording in your syllabus.

## 4. Technologies Used
| Technology | Used for |
| --- | --- |
| HTML5 | Page structure and forms |
| CSS3 | Flexbox, Grid, CSS variables, media queries, transitions, animations |
| JavaScript | Theme toggle, validation, chatbot, chat history, API calls |
| localStorage | Saving theme, chats, settings and the registered user |
| Google Gemini API (optional) | AI answers and image generation |
| Node.js + Express (optional) | Server that keeps the API key secret |
| Git and GitHub Pages | Version control and publishing |

## 5. Project Structure
```
elevo-chatbot/
├── index.html          # Product landing page
├── register.html       # Registration form
├── chat.html           # ELEVO chatbot
├── style.css           # All styles: colours, dark mode, landing, form, chat
├── script.js           # All JavaScript: dark mode, validation, chatbot, images
├── server.js           # Optional Node.js server (keeps the API key secret)
├── package.json        # Server dependencies
├── .env.example        # Template for the server API key
├── .gitignore          # Keeps .env and node_modules off GitHub
├── .nojekyll           # Tells GitHub Pages to publish files as they are
├── screenshots/        # Screenshots used in the README
├── README.md           # Project overview
└── DOCUMENTATION.md    # Full project documentation
```

---

## 6. Activity 1 – Product Landing Page (`index.html`)

### 6.1 Layout: Flexbox and Grid
| Section | Layout tool | Mobile | Desktop |
| --- | --- | --- | --- |
| Navbar | Flexbox | Logo and buttons on one row, links on a second row | Everything on one row |
| Hero | Flexbox | Text above the chat preview | Text beside the chat preview |
| Features | Grid | 1 column | 2 columns (600px), 3 columns (1024px) |
| How it works | Grid | 1 column | 3 columns (768px) |
| Modes | Grid | 1 column | 3 columns (768px) |
| Footer | Flexbox | Stacked | One row |

**Flexbox** arranges items in one direction (a row or a column). **Grid** arranges items in rows and columns at the same time.

```css
/* Flexbox: navbar */
.navbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
}

/* Grid: features, mobile first */
.features-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: 18px;
}

@media (min-width: 1024px) {
    .features-grid {
        grid-template-columns: repeat(3, 1fr);
    }
}
```

### 6.2 Dark/Light Mode
1. All colours are CSS variables at the top of `style.css`.
2. Dark values are set under `:root[data-theme="dark"]`.
3. Part 1 of `script.js` switches the `data-theme` attribute when the moon/sun button is clicked, and saves the choice in `localStorage`.
4. Because every page loads the same `style.css` and `script.js`, the theme stays the same across all pages.

```javascript
const next = root.getAttribute("data-theme") === "dark" ? "light" : "dark";
root.setAttribute("data-theme", next);
localStorage.setItem("elevo-theme", next);
```

The first time someone visits, ELEVO follows their device setting (dark or light).

---

## 7. Activity 2 – Registration Form (`register.html`)

### 7.1 Real-Time Validation Rules
Each field is checked on the `input` event, so the result appears while typing.

| Field | Rule | Example error |
| --- | --- | --- |
| Full name | Letters and spaces, at least 3 letters | "Name must have at least 3 letters." |
| Email | Must look like name@example.com | "Enter a valid email, like name@example.com." |
| Phone | Exactly 10 digits (letters are removed automatically) | "Phone number must be 10 digits (5 entered)." |
| Role | An option must be chosen | "Choose the option that describes you." |
| Password | 8+ characters, a capital letter, a number and a symbol | "Password needs 8 characters, a symbol." |
| Confirm password | Must match the password | "Passwords don't match." |
| Terms | Box must be ticked | "Tick the box to continue." |

```javascript
email.addEventListener("input", () => {
    const ok = /^[^\s@]+@[^\s@]+\.[a-zA-Z]{2,}$/.test(email.value.trim());
    // add the "valid" or "invalid" class and show the message
});
```

The form cannot be submitted until all 7 fields are valid. A counter shows how many fields are complete.

### 7.2 CSS Animations
| Animation | Technique | When it happens |
| --- | --- | --- |
| Slide-up | `@keyframes slide-up` | The form card appears on page load |
| Floating labels | `transition` on `top` and `font-size` | A field is focused or filled |
| Shake | `@keyframes shake` | A field is invalid on submit or when leaving it |
| Pop | `@keyframes pop` | The ✓ or ! icon appears |
| Strength bar | `transition` on `width` and colour | The password changes |
| Spinner | `@keyframes spin` | After clicking "Create account" |
| Drawing tick | `@keyframes draw` with `stroke-dashoffset` | The success message appears |

### 7.3 Data Saved
After a successful sign-up, the name, email, phone and role are saved in `localStorage`, and the chatbot greets the user by name. **The password is never saved.** In a real product, the password would be sent to a server over HTTPS and stored as a secure hash.

---

## 8. The Chatbot (`chat.html`)

### 8.1 How a Message Is Answered
1. The user types a message and presses Enter.
2. If the message asks for a picture ("draw ...", or the **Image** button is on), ELEVO creates an image.
3. In **offline mode**, the offline brain finds the best answer by matching keywords, or solves maths and conversions.
4. In **AI mode**, the message and recent chat are sent to Google Gemini (or Claude) and the reply is shown.
5. If the AI cannot be reached, ELEVO **automatically answers from offline mode**, so it always replies.
6. The reply is typed out word by word and the chat is saved.

### 8.2 Modes
| Mode | Needs internet | Needs a key | Answers |
| --- | --- | --- | --- |
| Offline (default) | No | No | 60+ built-in topics, maths, conversions, time, date, jokes |
| Google Gemini | Yes | Yes (free) | Any question |
| Anthropic Claude | Yes | Yes (paid) | Any question |
| Own server | Yes | Kept on the server | Any question |

### 8.3 Offline Knowledge
- **Web development:** HTML, CSS, JavaScript, Flexbox, Grid, media queries, DOM, events, Git, GitHub Pages
- **Programming:** Python, Java, C, OOP, data structures, SQL, algorithms
- **Science and GK:** solar system, gravity, photosynthesis, water cycle, Newton's laws
- **Study and career:** exams, viva, interviews, resumes, project ideas
- **Tools:** maths, percentages, square roots, unit conversions, time and date
- **Memory:** remembers the user's name

New answers can be added to the `KNOWLEDGE` list in Part 2 of `script.js`:
```javascript
{ keys: ["your keyword"], answer: "Your answer here." },
```

### 8.4 Image Generation
- Type "draw a cat astronaut", or turn on the **Image** button.
- Images come from a free service (no key) or from Google Gemini (with a key).
- Each image has **Download** and **Make another** buttons and is saved in the chat.
- Images need internet.

### 8.5 Chat History
- Every chat is saved and named after its first message.
- Chats are grouped by date (Today, Yesterday, Previous 7 days, Previous 30 days, Older).
- Chats can be searched, renamed and deleted (delete asks for a second click).
- Chats are stored in the browser, so they stay on the device where they were made.

---

## 9. Installation
1. Download or clone the repository.
2. Open the project folder.
3. Open `index.html` in Chrome or Edge.

No installation is needed for the website. The optional server:
1. Install Node.js 18 or newer.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and add the API key.
4. Run `npm start` and open http://localhost:3000

## 10. How to Use
1. Open the landing page and click **Create free account**.
2. Fill in the form and click **Create account**, then **Start chatting**.
3. Ask a question, such as "flexbox vs grid", "15% of 2000" or "10 km to miles".
4. For answers on any topic: gear icon → **Google Gemini** → paste a free key from https://aistudio.google.com/apikey → **Save**.
5. To create a picture, type "draw ..." or use the **Image** button.
6. Use the sidebar to open, search, rename or delete old chats.
7. Use the moon/sun button to switch between dark and light mode.

---

## 11. Testing
The whole project was tested automatically in Chrome, served over HTTP the same way GitHub Pages serves it, with external fonts blocked to check it still works without them.

**Result: 36 of 36 tests passed.**

| # | Test | Result |
| --- | --- | --- |
| 1 | Landing page loads | Pass |
| 2 | Dark mode toggle | Pass |
| 3 | Guest can open chat | Pass |
| 4 | Offline answer: "hello" | Pass |
| 5 | Offline answer: "what is html" | Pass |
| 6 | Offline answer: "flexbox vs grid" | Pass |
| 7 | Offline answer: "125 * 8 + 40" | Pass |
| 8 | Offline answer: "15% of 2000" | Pass |
| 9 | Offline answer: "10 km to miles" | Pass |
| 10 | Offline answer: "37 c to f" | Pass |
| 11 | Offline answer: "my name is Ravi" | Pass |
| 12 | Offline answer: "what is my name" | Pass |
| 13 | Offline answer: "explain oop" | Pass |
| 14 | Offline answer: "tips for viva" | Pass |
| 15 | Offline answer: "tell me a joke" | Pass |
| 16 | Offline answer: "what is the time" | Pass |
| 17 | Unknown question handled politely | Pass |
| 18 | Image request creates an image | Pass |
| 19 | Stop button works | Pass |
| 20 | Chat history saves chats | Pass |
| 21 | Chats kept after refresh | Pass |
| 22 | Search chats | Pass |
| 23 | AI mode falls back to offline if AI unreachable | Pass |
| 24 | AI mode answers with Gemini (simulated) | Pass |
| 25 | Empty form is blocked | Pass |
| 26 | Real-time email check | Pass |
| 27 | Strength meter | Pass |
| 28 | Registration succeeds | Pass |
| 29 | Password not stored | Pass |
| 30 | Chat greets registered user | Pass |
| 31 | No horizontal scroll at 320px | Pass |
| 32 | No horizontal scroll at 375px | Pass |
| 33 | No horizontal scroll at 768px | Pass |
| 34 | No horizontal scroll at 1440px | Pass |
| 35 | Mobile chat menu opens | Pass |
| 36 | No JavaScript errors | Pass |

**Notes on testing**
- AI answers and images were tested with simulated responses, because the test computer could not reach outside websites. With a real key and internet, the same code calls the real services.
- Screen widths tested: 320px, 375px, 768px and 1440px on all three pages (425px and 1024px were also checked during development).

---

## 12. Publishing on GitHub
1. Create a new public repository named `elevo-chatbot` (leave "Add a README" unticked).
2. Upload all project files, or run:
```
git init
git add .
git commit -m "ELEVO AI chatbot"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/elevo-chatbot.git
git push -u origin main
```
3. Go to **Settings → Pages**, choose **Deploy from a branch**, select `main` and `/ (root)`, and click **Save**.
4. Open `https://YOUR-USERNAME.github.io/elevo-chatbot/` after a minute or two.

## 13. Screenshots
| Landing page (light) | Landing page (dark) | Landing page (mobile) |
| --- | --- | --- |
| ![Landing light](screenshots/landing-light.png) | ![Landing dark](screenshots/landing-dark.png) | ![Landing mobile](screenshots/landing-mobile.png) |

| Form errors | Validation while typing | Registration success |
| --- | --- | --- |
| ![Form errors](screenshots/register-errors.png) | ![Real-time validation](screenshots/register-typing.png) | ![Success](screenshots/register-success.png) |

| Chat (desktop) | Chat (dark) | Chat (mobile) |
| --- | --- | --- |
| ![Chat desktop](screenshots/chat-desktop.png) | ![Chat dark](screenshots/chat-dark.png) | ![Chat mobile](screenshots/chat-mobile.png) |

## 14. Security Notes
- API keys are **never stored in the code**. They are saved only in the user's own browser.
- `.gitignore` stops the server's `.env` file from being uploaded to GitHub.
- Passwords from the registration form are **not saved**.
- Chat text is escaped before it is shown, so typed HTML cannot run as code.

## 15. Limitations
- Offline mode only knows the topics in its knowledge list; for anything else it suggests AI mode.
- AI answers and images need internet and a working service.
- Chats and accounts are saved per browser, not across devices.
- The free image service can be slow and may change its rules.

## 16. Future Enhancements
- Cloud database so chats and accounts sync across devices
- Login page with secure server-side passwords
- Voice input and spoken replies
- Mobile app version
- More topics in the offline knowledge base

## 17. Conclusion
ELEVO meets both activity requirements in one project: a responsive product landing page built with Flexbox and Grid with a dark/light toggle, and a registration form with CSS animations and real-time validation. It follows the Unit 2 manual rules (raw HTML/CSS, mobile-first, media queries, tested widths, README and GitHub Pages) and adds a working chatbot that always replies, online or offline.

### Requirements Checklist

**Question 1: Product landing page using CSS3 Flexbox and Grid with dark/light mode toggle**
- [x] Product landing page for ELEVO (`index.html`)
- [x] Flexbox: navbar, hero, buttons, preview chat, footer
- [x] Grid: features (1 → 2 → 3 columns), steps and modes (1 → 3 columns)
- [x] Dark/light mode toggle with CSS variables, saved in `localStorage`

**Question 2: Interactive registration form with CSS animations and real-time client-side validation**
- [x] Registration form (`register.html`) with 7 validated fields
- [x] Real-time validation using the `input` event and regular expressions
- [x] 7 CSS animations using `@keyframes` and transitions
- [x] Submission blocked until every field is valid

**Unit 2 manual rules**
- [x] Raw HTML, CSS and JavaScript; no Bootstrap, Tailwind or other UI framework
- [x] Mobile layout written first, then `min-width` media queries for larger screens
- [x] Tested at 320px, 375px, 425px, 768px, 1024px and 1440px with no horizontal scrolling
- [x] README with Introduction, Features, Technologies Used, Installation, Usage and Future Enhancements
- [x] Ready for GitHub Pages (`index.html` in the root folder)
