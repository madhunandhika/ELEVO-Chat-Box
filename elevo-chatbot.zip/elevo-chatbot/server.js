// ELEVO server – keeps your API key secret on the server.
// 1. npm install   2. copy .env.example to .env and add your key   3. npm start
// Then open http://localhost:3000 (landing page) or /chat.html
require("dotenv").config();
const express = require("express");
const path = require("path");

const app = express();
app.use(express.json({ limit: "1mb" }));
app.use(express.static(__dirname));

const PERSONA =
    "You are ELEVO, a friendly and helpful AI assistant. If asked your name, say you are ELEVO. " +
    "Answer clearly and simply. Keep replies short unless the user asks for detail.";

const GEMINI_KEY = process.env.GEMINI_API_KEY;
const CLAUDE_KEY = process.env.ANTHROPIC_API_KEY;
const GEMINI_MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash";
const CLAUDE_MODEL = process.env.CLAUDE_MODEL || "claude-haiku-4-5-20251001";

app.post("/api/chat", async (req, res) => {
    const messages = Array.isArray(req.body.messages) ? req.body.messages.slice(-20) : [];
    if (messages.length === 0) return res.status(400).json({ error: "No messages sent." });

    try {
        let reply = "";

        if (GEMINI_KEY) {
            const url = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${GEMINI_KEY}`;
            const r = await fetch(url, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    systemInstruction: { parts: [{ text: PERSONA }] },
                    contents: messages.map(m => ({
                        role: m.role === "assistant" ? "model" : "user",
                        parts: [{ text: String(m.content) }]
                    }))
                })
            });
            const data = await r.json();
            if (!r.ok) return res.status(r.status).json({ error: data?.error?.message || "Gemini error" });
            reply = (data?.candidates?.[0]?.content?.parts || []).map(p => p.text || "").join("");

        } else if (CLAUDE_KEY) {
            const r = await fetch("https://api.anthropic.com/v1/messages", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "x-api-key": CLAUDE_KEY,
                    "anthropic-version": "2023-06-01"
                },
                body: JSON.stringify({
                    model: CLAUDE_MODEL,
                    max_tokens: 1024,
                    system: PERSONA,
                    messages: messages.map(m => ({ role: m.role, content: String(m.content) }))
                })
            });
            const data = await r.json();
            if (!r.ok) return res.status(r.status).json({ error: data?.error?.message || "Claude error" });
            reply = (data.content || []).filter(b => b.type === "text").map(b => b.text).join("");

        } else {
            return res.status(500).json({ error: "No API key found. Add GEMINI_API_KEY or ANTHROPIC_API_KEY to the .env file." });
        }

        res.json({ reply });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`ELEVO is running at http://localhost:${PORT}`));
